import React ,{Component} from "react";
class Leftnav extends Component{
    render(){
        return(
            <div></div> 
        )
    }
}

export default Leftnav